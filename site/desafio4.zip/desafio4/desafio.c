#include <stdio.h>

int main(void)
{
	char buff[64] = {0};

	scanf("%s", buff);
	printf(buff);
	printf("\n");

	scanf("%s", buff);
	printf(buff);
	printf("\n");
}
